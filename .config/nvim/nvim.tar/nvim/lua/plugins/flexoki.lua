return { 'kepano/flexoki-neovim', 
  name = 'flexoki',
  config = function ()
    vim.cmd('colorscheme flexoki-dark')
  end
}

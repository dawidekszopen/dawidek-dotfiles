return {
  "alefpereira/pyenv-pyright"
}
